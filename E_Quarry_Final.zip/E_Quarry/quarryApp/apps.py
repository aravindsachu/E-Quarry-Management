from django.apps import AppConfig


class QuarryAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'quarryApp'
